# 🔐 JWT Cheat Sheet

## Store JWT in localStorage
```js
localStorage.setItem("token", jwt);
```

## Retrieve
```js
const token = localStorage.getItem("token");
```

## Send JWT in Authorization Header
```js
fetch("/api/resource", {
  headers: {
    "Authorization": "Bearer " + token
  }
});
```

## Check login
```js
if (!localStorage.getItem("token")) {
  window.location.href = "/login.html";
}
```
