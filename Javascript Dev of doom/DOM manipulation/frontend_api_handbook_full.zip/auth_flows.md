# 🔑 Auth Flows

## Login Flow
1. User submits login form.
2. Frontend sends username/password.
3. Backend returns JWT.
4. Frontend stores JWT in localStorage.
5. Redirect user to dashboard.

### Example
```js
async function login(e) {
  e.preventDefault();
  const fd = new FormData(e.target);
  const data = Object.fromEntries(fd);

  const res = await fetch("/api/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  });

  const json = await res.json();
  localStorage.setItem("token", json.token);
  window.location.href = "/dashboard.html";
}
```

## Protected Route
```js
if (!localStorage.getItem("token")) {
  window.location.href = "/login.html";
}
```

## Logout
```js
localStorage.removeItem("token");
window.location.href = "/login.html";
```
