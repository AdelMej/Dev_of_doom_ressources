# 🍪 Cookies Cheat Sheet (JavaScript)

## ✅ Set a Cookie
```js
document.cookie = "token=abc123; path=/; max-age=3600";
```

## ✅ Read a Cookie
```js
function getCookie(name) {
  return document.cookie
    .split("; ")
    .find(row => row.startsWith(name + "="))
    ?.split("=")[1];
}
```

## ✅ Delete Cookie
```js
document.cookie = "token=; Max-Age=0; path=/";
```

## Notes
- Cookies are sent automatically with every HTTP request to the same domain.
- Avoid storing JWTs in cookies unless they are HttpOnly and Secure (backend-set).
