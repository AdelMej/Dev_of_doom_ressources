# 🌐 Fetch API Patterns

## Basic GET
```js
const res = await fetch(url);
const data = await res.json();
```

## POST JSON
```js
fetch(url, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify({ name: "Alice" })
});
```

## POST FormData
```js
const fd = new FormData(form);
fetch(url, { method: "POST", body: fd });
```

## Error handling
```js
if (!res.ok) {
  console.error("HTTP error", res.status);
}
```
