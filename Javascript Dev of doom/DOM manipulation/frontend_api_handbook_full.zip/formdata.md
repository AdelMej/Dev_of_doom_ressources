# 📘 FormData Cheat Sheet

## Create
```js
const fd = new FormData(document.querySelector("form"));
```

## Read values
```js
fd.get("username");
fd.getAll("hobbies");
```

## Loop
```js
for (const [key, value] of fd.entries()) {
  console.log(key, value);
}
```

## Convert FormData → JSON
```js
const json = Object.fromEntries(fd.entries());
```

## Upload files
```js
const file = fd.get("avatar");
console.log(file.name);
```
